"""PEP 517 build backend for optionally pre-building Cython."""
